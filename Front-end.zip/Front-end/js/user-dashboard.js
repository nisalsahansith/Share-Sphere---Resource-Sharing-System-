$("#openSidebar").on("click", function () {
    $("#sidebar").addClass("active");
});
$("#closeSidebar").on("click", function () {
    $("#sidebar").removeClass("active");
});

$(document).ready(function () {
    loadListings();
    loadSkills();
});

// $(document).ready(function () {
//     const modalEl = document.getElementById("listingModal");
//     const modal = new bootstrap.Modal(modalEl);

//     $(".view-btn").click(function () {
//       const title = $(this).data("title");
//       const image = $(this).data("image");
//       const description = $(this).data("description");
//       const condition = $(this).data("condition");
//       const priceHour = $(this).data("pricehour");
//       const priceDay = $(this).data("priceday");

//       $("#modalTitle").text(title);
//       $("#modalImage").attr("src", image).attr("alt", title);
//       $("#modalDescription").text(description);
//       $("#modalCondition").text(condition);
//       $("#modalPriceHour").text(priceHour);
//       $("#modalPriceDay").text(priceDay);

//       modal.show();
//     });

//     document.getElementById('modalCloseBtn').addEventListener('click', () => {
//         modal.hide();
//     });
// });

// Example: Your View buttons should look like this:
// <button class="btn btn-primary view-btn" data-type="tool" data-id="1">View</button>
// <button class="btn btn-primary view-btn" data-type="skill" data-id="2">View</button>

$(document).on("click", ".view-btn", function () {
    const type = $(this).data("type"); // "tool" or "skill"
    const id = $(this).data("id");

    if (!id) {
        console.error("ID is undefined for view button");
        return;
    }

    // Build URL with query parameter
    const url = type === "tool"
        ? `http://localhost:8080/user/getatool?toolId=${id}`
        : `http://localhost:8080/user/getaskill?skillId=${id}`;

    $.ajax({
        url: url,
        type: "GET",
        headers: {
            "Authorization": "Bearer " + localStorage.getItem("token")
        },
        success: function(response) {
            const data = response.data;

            if (!data) {
                alert("No data found for this item.");
                return;
            }

            // Populate modal
            $("#modalTitle").text(data.name || "");
            $("#modalDescription").text(data.description || "");

            if (type === "tool") {
                $("#modalConditionRow").show();
                $("#modalCondition").text(data.condition || "N/A");
            } else {
                $("#modalConditionRow").hide();
            }

            $("#modalPrice").text(data.price || "0");
            $("#modalPriceType").text(data.priceType || "");

            // Build carousel
            let carouselInner = $("#modalCarouselInner");
            carouselInner.empty();
            if (data.imageUrls && data.imageUrls.length) {
                $.each(data.imageUrls, function(i, img) {
                    carouselInner.append(`
                        <div class="carousel-item ${i === 0 ? "active" : ""}">
                            <img src="${img}" class="d-block w-100 rounded" alt="Listing Image">
                        </div>
                    `);
                });
            } else {
                carouselInner.append(`<div class="carousel-item active">
                    <img src="placeholder.jpg" class="d-block w-100 rounded" alt="No Image">
                </div>`);
            }

            const ul = $("#availableTimes");
            ul.empty();
            if (data.startDate && data.endDate) {
                const start = new Date(data.startDate);
                const end = new Date(data.endDate);
                for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
                    const dayStr = d.toISOString().split("T")[0];
                    ul.append(`<li class="list-group-item">${dayStr}</li>`);
                }
            }

            $("#listingModal").modal("show");
        },
        error: function(xhr, status, error) {
            console.error("Error fetching listing:", xhr.responseText || error);
            alert("Could not load listing details. Make sure you are logged in.");
        }
    });
});


  
// $("#view-btn").click(function() {
//     const modalEl = document.getElementById('listingModal');
//     const modal = new bootstrap.Modal(modalEl);
//     modal.show();
//   });

$(document).ready(function () {
        // Listing modal data setup
        $('#listingModal').on('show.bs.modal', function (event) {
            const button = $(event.relatedTarget);
            $('#modalTitle').text(button.data('title'));
            $('#modalDescription').text(button.data('description'));
            $('#modalCondition').text(button.data('conditions'));
            $('#modalPriceHour').text(button.data('pricehour'));
            $('#modalPriceDay').text(button.data('priceday'));
            $('#modalImage').attr('src', button.data('image'));
        });

        // Show payment modal after booking form submit
        $('#bookingForm').on('submit', function (e) {
            e.preventDefault();

            // Close booking modal
            $('#listingModal').modal('hide');

            // Open payment modal
            $('#paymentModal').modal('show');
        });

        // Toggle card details based on payment method
        $('#paymentMethod').on('change', function () {
            if ($(this).val() === 'card') {
                $('#cardDetails').show();
            } else {
                $('#cardDetails').hide();
            }
        });

        // Handle payment form submit
        $('#paymentForm').on('submit', function (e) {
            e.preventDefault();
            alert("✅ Payment Successful! Your booking is confirmed.");

            // Close payment modal
            $('#paymentModal').modal('hide');
        });
});
    

function loadListings() {
  const token = localStorage.getItem("token");

  $.ajax({
    url: "http://localhost:8080/user/getalltools",
    type: "GET",
    headers: {
      "Authorization": "Bearer " + token
    },
    success: function(response) {
      const listings = response.data; // ✅ your array is inside "data"

      if (!Array.isArray(listings)) {
        console.error("Expected array in response.data but got:", listings);
        return;
      }

      const container = $("#listingContainer");
      container.empty();

      listings.forEach((listing, index) => {
        // Create carousel slides
        let carouselItems = listing.imageUrls.map((img, i) => `
          <div class="carousel-item ${i === 0 ? "active" : ""}">
            <img src="${img}" class="d-block w-100" style="height: 180px; object-fit: cover;" alt="${listing.name}">
          </div>
        `).join("");

        // Create card HTML
        const card = `
          <div class="card listing-card" style="width: 250px;">
            <div id="carousel-${listing.toolId}" class="carousel slide" data-bs-ride="carousel">
              <div class="carousel-inner">
                ${carouselItems}
              </div>
              <button class="carousel-control-prev" type="button" data-bs-target="#carousel-${listing.toolId}" data-bs-slide="prev">
                <span class="carousel-control-prev-icon"></span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carousel-${listing.toolId}" data-bs-slide="next">
                <span class="carousel-control-next-icon"></span>
              </button>
            </div>
            <div class="card-body">
              <h5 class="card-title">${listing.name}</h5>
              <p class="card-text">Available for rent</p>
              <p class="fw-bold">$${listing.price} ${listing.priceType === "PER_DAY" ? "/day" : "/hour"}</p>
              <button 
                class="btn btn-primary btn-sm view-btn" 
                data-bs-toggle="modal" 
                data-bs-target="#listingModal"
                data-type="tool"
                data-id="${listing.toolId}"
                data-title="${listing.name}"
                data-price="${listing.price}"
                data-pricetype="${listing.priceType}"
                data-description="${listing.description}"
                data-conditions="${listing.condition}"
                data-images='${JSON.stringify(listing.imageUrls)}'
                >
                View
            </button>

            </div>
          </div>
        `;

        container.append(card);
      });
    },
    error: function(xhr, status, error) {
      console.error("Error loading listings:", xhr.responseText);
    }
  });
}

function loadSkills() {
  const token = localStorage.getItem("token");

  $.ajax({
    url: "http://localhost:8080/user/getallskills",
    type: "GET",
    headers: {
      "Authorization": "Bearer " + token
    },
    success: function(response) {
      const skills = response.data;

      if (!Array.isArray(skills)) {
        console.error("Expected array in response.data but got:", skills);
        return;
      }

      const container = $("#skillsContainer");
      container.empty();

      skills.forEach((skill, index) => {
        // Create carousel slides
        let carouselItems = skill.imageUrls.map((img, i) => `
          <div class="carousel-item ${i === 0 ? "active" : ""}">
            <img src="${img}" class="d-block w-100" style="height: 180px; object-fit: cover;" alt="${skill.name}">
          </div>
        `).join("");

        // Create card HTML
        const card = `
          <div class="card listing-card" style="width: 250px;">
            <div id="skill-carousel-${skill.skillId}" class="carousel slide" data-bs-ride="carousel">
              <div class="carousel-inner">
                ${carouselItems}
              </div>
              <button class="carousel-control-prev" type="button" data-bs-target="#skill-carousel-${skill.skillId}" data-bs-slide="prev">
                <span class="carousel-control-prev-icon"></span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#skill-carousel-${skill.skillId}" data-bs-slide="next">
                <span class="carousel-control-next-icon"></span>
              </button>
            </div>
            <div class="card-body">
              <h5 class="card-title">${skill.name}</h5>
              <p class="card-text">${skill.availability}</p>
              <p class="fw-bold">$${skill.price} ${skill.priceType === "PER_DAY" ? "/day" : "/Fixed"}</p>
              <button 
                class="btn btn-primary btn-sm view-btn" 
                data-bs-toggle="modal" 
                data-bs-target="#listingModal"
                data-type="skill"
                data-id="${skill.skillId}"
                data-title="${skill.name}"
                data-price="${skill.price}"
                data-pricetype="${skill.priceType}"
                data-description="${skill.description}"
                data-conditions="${skill.availability}"
                data-images='${JSON.stringify(skill.imageUrls)}'
                >
                View
            </button>

            </div>
          </div>
        `;

        container.append(card);
      });
    },
    error: function(xhr, status, error) {
      console.error("Error loading skills:", xhr.responseText);
    }
  });
}


$(document).on("click", ".logout-btn", function () {
    localStorage.removeItem("token");
    localStorage.removeItem("userId");
    
    window.location.href = "/index.html"; // change if your login page has a different path
});




