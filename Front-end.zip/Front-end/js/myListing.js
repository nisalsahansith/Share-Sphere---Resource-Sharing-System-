$(document).ready(function () {
    const userId = localStorage.getItem("userId"); // Replace with actual userId

        $.ajax({
            url: "http://localhost:8080/mylistings/getmyskills",
            type: "GET",
            data: { userId: userId },
            headers: { "Authorization": "Bearer " + localStorage.getItem("token") },
            success: function (response) {
            if (response.data && Array.isArray(response.data)) {
                let listingsHtml = "";
                response.data.forEach((skill, index) => {
                    let carouselItems = "";
                    if (skill.imageUrls && skill.imageUrls.length > 0) {
                        skill.imageUrls.forEach((url, imgIndex) => {
                            carouselItems += `
                                <div class="carousel-item ${imgIndex === 0 ? "active" : ""}">
                                    <img src="${url}" class="d-block w-100" alt="Listing Image">
                                </div>
                            `;
                        });
                    } else {
                        carouselItems = `
                            <div class="carousel-item active">
                                <img src="https://via.placeholder.com/150" class="d-block w-100" alt="Listing Image">
                            </div>
                        `;
                    }

                    listingsHtml += `
                    <div class="col-md-4">
                        <div class="card listing-card">
                            <div id="carousel${index}" class="carousel slide" data-bs-ride="carousel">
                                <div class="carousel-inner">
                                    ${carouselItems}
                                </div>
                                <button class="carousel-control-prev" type="button" data-bs-target="#carousel${index}" data-bs-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Previous</span>
                                </button>
                                <button class="carousel-control-next" type="button" data-bs-target="#carousel${index}" data-bs-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Next</span>
                                </button>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">${skill.name}</h5>
                                <p class="text-muted mb-1">${skill.availability}</p>
                                <p><span class="badge bg-info">${skill.startDate || ''} → ${skill.endDate || ''}</span></p>
                                <p><strong>Bookings:</strong> <span class="badge bg-secondary">${skill.bookings || 0}</span></p>
                                <div class="card-actions">
                                    <i class="bi bi-pencil-square text-warning action-icon" data-bs-toggle="modal" data-bs-target="#editListingModal"></i>
                                    <i class="bi bi-trash text-danger action-icon"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    `;
                });
                $("#listingsContainer").html(listingsHtml);
            } else {
                $("#listingsContainer").html("<p>No listings found.</p>");
            }
        },
            error: function (err) {
                console.error(err);
                $("#listingsContainer").html("<p>Error loading listings.</p>");
            }
        });
    });


$(document).ready(function () {
    const userId = localStorage.getItem("userId"); // Replace with actual userId

    $.ajax({
        url: "http://localhost:8080/mylistings/getmytools", // Tools API
        type: "GET",
        data: { userId: userId },
        headers: { "Authorization": "Bearer " + localStorage.getItem("token") },
        success: function (response) {
            if (response.data && Array.isArray(response.data)) {
                let toolsHtml = "";
                response.data.forEach((tool, index) => {
                    let carouselItems = "";
                    if (tool.imageUrls && tool.imageUrls.length > 0) {
                        tool.imageUrls.forEach((url, imgIndex) => {
                            carouselItems += `
                                <div class="carousel-item ${imgIndex === 0 ? "active" : ""}">
                                    <img src="${url}" class="d-block w-100" alt="Tool Image">
                                </div>
                            `;
                        });
                    } else {
                        carouselItems = `
                            <div class="carousel-item active">
                                <img src="https://via.placeholder.com/150" class="d-block w-100" alt="Tool Image">
                            </div>
                        `;
                    }

                    toolsHtml += `
                    <div class="col-md-4">
                        <div class="card listing-card">
                            <div id="toolCarousel${index}" class="carousel slide" data-bs-ride="carousel">
                                <div class="carousel-inner">
                                    ${carouselItems}
                                </div>
                                <button class="carousel-control-prev" type="button" data-bs-target="#toolCarousel${index}" data-bs-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Previous</span>
                                </button>
                                <button class="carousel-control-next" type="button" data-bs-target="#toolCarousel${index}" data-bs-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Next</span>
                                </button>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">${tool.name}</h5>
                                <p class="text-muted mb-1">${tool.availabilityStatus}</p>
                                <p><span class="badge bg-success">${tool.startDate || ''} → ${tool.endDate || ''}</span></p>
                                <p><strong>Bookings:</strong> <span class="badge bg-secondary">${tool.bookings || 0}</span></p>
                                <div class="card-actions">
                                    <i class="bi bi-pencil-square text-warning action-icon" data-bs-toggle="modal" data-bs-target="#editListingModal"></i>
                                    <i class="bi bi-trash text-danger action-icon"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    `;
                });
                $("#toolsContainer").html(toolsHtml);
            } else {
                $("#toolsContainer").html("<p>No tools found.</p>");
            }
        },
        error: function (err) {
            console.error(err);
            $("#toolsContainer").html("<p>Error loading tools.</p>");
        }
    });
});
